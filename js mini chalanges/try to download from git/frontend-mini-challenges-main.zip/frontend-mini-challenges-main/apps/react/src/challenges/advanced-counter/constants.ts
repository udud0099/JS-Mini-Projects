export const minStep = 1;
export const maxStep = 100;
export const minDelay = 1;
export const maxDelay = 3;
export const minLimit = -1000;
export const maxLimit = 1000;
