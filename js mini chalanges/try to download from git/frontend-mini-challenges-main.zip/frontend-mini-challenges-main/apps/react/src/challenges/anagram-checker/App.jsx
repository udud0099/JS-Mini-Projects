import React from 'react'
import AnagramChecker from './Anagramchecker'

const App = () => {
  return (
    <div>
      <AnagramChecker/>
    </div>
  )
}

export default App;
