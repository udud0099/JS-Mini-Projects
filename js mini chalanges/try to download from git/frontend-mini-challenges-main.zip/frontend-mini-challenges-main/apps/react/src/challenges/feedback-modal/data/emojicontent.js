const content = [
  {
    rating: 1,
    url: 'https://cdn-icons-png.flaticon.com/512/14230/14230791.png',
    mood: 'Terrible',
  },
  {
    rating: 2,
    url: 'https://cdn-icons-png.flaticon.com/512/166/166527.png',
    mood: 'Unhappy',
  },
  {
    rating: 3,
    url: 'https://cdn-icons-png.flaticon.com/512/1791/1791385.png',
    mood: 'Neutral',
  },
  {
    rating: 4,
    url: 'https://cdn-icons-png.flaticon.com/512/166/166538.png',
    mood: 'Happy',
  },
  {
    rating: 5,
    url: 'https://cdn-icons-png.flaticon.com/512/10851/10851309.png',
    mood: 'Excited',
  },
];

export default content;
