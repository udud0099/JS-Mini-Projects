export type OptionType = {
  id: string;
  text: string;
  isDisabled?: boolean;
};
