export interface IContributor {
  username: string;
  avatar: string;
}

export const maintainersList: IContributor[] = [
  { username: 'sadanandpai', avatar: '12962887' },
  { username: 'arpansaha13', avatar: '82361490' },
];
