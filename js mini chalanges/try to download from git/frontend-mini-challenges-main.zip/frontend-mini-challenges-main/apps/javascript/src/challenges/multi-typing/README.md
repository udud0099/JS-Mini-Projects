# **Multi Typing**

---

<br>

## **Description 📃**

- This is a mini project which shows multi typing and also have customization options and it's made
  using HTML, CSS and JS

## **Functionalities 🎮**

- Shows multiple words typing and remoing
- User can also add the words and increase/decrease the speed of typing </br>

## **How to play? 🕹️**

- Add words by writing in input and click on submit and wait for your word, user can add as many
  words as they want.
- User can increase/decrease the speed using slider. To decrase the speed, slide to right, to
  increase the spee slide to right.

</br>
