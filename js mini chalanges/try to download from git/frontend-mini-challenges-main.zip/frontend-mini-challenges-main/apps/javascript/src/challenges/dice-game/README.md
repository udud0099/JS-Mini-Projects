# **S: Dice Game - Replace images with HTML and CSS**

---

</br>

## **Description 📃**

- This is a mini project which rolls two dice and show which player won and it's made using HTML,CSS
  and JS

## **Functionalities 🎮**

- After clicking on the button, rolls dice and show two nummbers.
- Player who has grater number will win </br>

## **How to play? 🕹️**

- Click on the Play button

</br>
